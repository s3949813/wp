function navigate(page) {
    if (page) {
        window.location.href = page;
    }
}

